#ifndef _TRIANGLE_H
#define _TRIANGLE_H

#include "surface.h"
#include "rgb.h"
#include "vector3d.h"

class triangle : public surface

{
 public:
  triangle();
  triangle( const vector3d & np0, const vector3d & np1, const vector3d & np2, const rgb & kd, const rgb & ks, double kh, double e );
  
  vector3d p0() const
  {
    return myP0;
  }
  vector3d p1() const
  {
    return myP1;
  }
  vector3d p2() const
  {
    return myP2;
  }

  void setp0( const vector3d & p0 )
  {
    myP0 = vector3d(p0);
  } 
  void setp1( const vector3d & p1 )
  {
    myP1 = vector3d(p1);
  } 
  void setp2( const vector3d & p2 )
  {
    myP2 = vector3d(p2);
  }

  vector3d normal() const
  {
    vector3d temp = cross( p1()-p0() , p2()-p0() );
    return temp/temp.length();
  }

  bool hit (const ray & r, double tmin, double tmax, double & t, surfacevals & sv ) const; 

  vector3d centroid() const;
  dynarray<vector3d> elements() const;

  //private:
  vector3d myP0, myP1, myP2;
};

#endif




