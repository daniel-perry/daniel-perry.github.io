#include "scene.h"
#include "sphere.h"
#include "triangle.h"
#include "axisbox.h"
#include "light.h"
#include <string>

#include <stdlib.h>

#include <float.h>

#define MYMAXFLOAT FLT_MAX
// Linux: FLT_MAX
// Sun: MAXFLOAT

/*
scene::~scene()
{
  del_tree( mySurfaces );
}

void del_tree( surface * treeNode)
{
  if( treeNode != 0 )
  {
    del_tree( treeNode -> left);
    del_tree( treeNode -> right);
  }
  delete treeNode;
}
*/


void scene::read( istream & is)
{
  string objectName;
  sphere s1;
  triangle t1;
  axisbox b1;
  light l1;

  dynarray<surface*> surfaceList;
  
  while( is >> objectName )
  {
    if ( objectName == "sphere" )
    {
      is >> s1.myCenter >> s1.myRadius >> s1.myMatteColor >> s1.myMirrorColor >> s1.myHighlightConst >> s1.myPhongExponent;
      surfaceList.append( new sphere( s1 ) );
    }
    else if ( objectName == "triangle" )
    {
      is >> t1.myP0 >> t1.myP1 >> t1.myP2 >> t1.myMatteColor >> t1.myMirrorColor >> t1.myHighlightConst >> t1.myPhongExponent;
      surfaceList.append( new triangle( t1 ) );
    }
    else if ( objectName == "box" )
    {
      is >> b1.myP0 >> b1.myP1 >> b1.myMatteColor >> b1.myMirrorColor >> b1.myHighlightConst >> b1.myPhongExponent;
      surfaceList.append( new axisbox( b1 ) );
    }
    else if ( objectName == "light" )
    {
      is >> l1.myDirection >> l1.myColor;
      l1.setdirection( l1.direction()/l1.direction().length() ); // normalize
      addlight( light( l1 ) );
    }
    else if ( objectName == "ambient" )
    {      
      is >> myAmbient;
    }
    else if ( objectName == "background" )
    {
      is >> myBackground;
    }
  }

  
  mySurfaces = build_tree( surfaceList , 0 );
  
}

int compareX ( const void * v1 , const void * v2 )
{
  surface ** s1 = (surface **) v1, **s2 = (surface **) v2;
  vector3d c1 = (*s1)->centroid(), c2 = (*s2)->centroid();
  if ( c1.x() > c2.x() )
    return 1;
  else if ( c1.x() == c2.x() )
    return 0;
  else
    return -1;
}

int compareY ( const void * v1 , const void * v2 )
{
  surface ** s1 = (surface **) v1, **s2 = (surface **) v2;
  vector3d c1 = (*s1)->centroid(), c2 = (*s2)->centroid();
  if ( c1.y() > c2.y() )
    return 1;
  else if ( c1.y() == c2.y() )
    return 0;
  else
    return -1;
}

int compareZ ( const void * v1 , const void * v2 )
{
  surface ** s1 = (surface **) v1, **s2 = (surface **) v2;
  vector3d c1 = (*s1)->centroid(), c2 = (*s2)->centroid();
  if ( c1.z() > c2.z() )
    return 1;
  else if ( c1.z() == c2.z() )
    return 0;
  else
    return -1;
}

surface * build_tree ( const dynarray<surface*> objectList , int axis )
{

  if ( objectList.length() == 0 )
    return 0;
  else if ( objectList.length() == 1 )
    return objectList[0];
  
  switch ( axis % 3 )
  {
  case 0:
    qsort( objectList.data , objectList.length() , sizeof(surface*), compareX );
    break;
  case 1:
    qsort( objectList.data , objectList.length() , sizeof(surface*), compareY );
    break;
  case 2:
    qsort( objectList.data , objectList.length() , sizeof(surface*), compareZ );
    break;
  }
  
  vector3d max, min;
  max = min = objectList[0]->elements()[0];
  dynarray<vector3d> tempArray;
  double x,y,z;
  
  for( int i=0 ; i<objectList.length() ; i++)
  {
    tempArray = objectList[i]->elements();
    for (int j=0; j<tempArray.length(); j++)
    {
      x = tempArray[j].x();
      if ( x > max.x() )
	max.setx(x);
      if ( x < min.x() )
	min.setx(x);
      
      y = tempArray[j].y();
      if ( y > max.y() )
	max.sety(y);
      if ( y < min.y() )
	min.sety(y);
      
      z = tempArray[j].z();
      if ( z > max.z() )
	max.setz(z);
      if ( z < min.z() )
	min.setz(z);
    }
  }
  
  int subDiv = objectList.length()/2;
  
  surface * left = build_tree( objectList.sub(0,subDiv) , axis+1 );
  
  surface * right = build_tree( objectList.sub(subDiv, objectList.length() - subDiv) , axis+1 );
  boundingbox b1(min,max);

  return new hbv_node( b1 , left , right );
  
}



/*
double danMax(double a, double b)
{
  return a < b ? b : a;
}

bool scene::hit( const ray & r, double tmin, double tmax, double & t, surfacevals & sv)
{
  bool hitp = false;
  double tminHit = tmax;
  surfacevals svmin;

  for(int i = 0; i < mySurfaces.length(); i++)
  {
    if( mySurfaces[i]->hit( r, tmin, tmax, t, sv) )
    {
      hitp = true;
      if ( t <= tminHit )
      {
	tminHit = t;
	svmin = sv;
      }
    }
  } 
  
  if (hitp)
  {
    t = tminHit;
    sv = svmin;
    return true;
  }
  return false;
}
*/

rgb scene::color( const ray & r, double tmin, double tmax )
{
  /*  
  double t;
  const double epsilon = 0.00001;
  surfacevals sv;
      
  if ( hit( r, tmin, tmax, t, sv) )
  {
    rgb allLight(0,0,0);
    rgb highlight_color(0,0,0);
    vector3d half;
    double dumbt;
    surfacevals dumbsv;

    for (int i = 0; i < myLights.length(); i++)
    {
      if ( ! (hit( ray( r.eval(t) , myLights[i].direction() ) , epsilon , tmax , dumbt , dumbsv )) )  // makes shadow
	{
	  allLight += myLights[i].color() * danMax( 0.0 , dot( myLights[i].direction() , sv.normal ) );
      
	  half = unitVector( sv.normal - myLights[i].direction() );
	  highlight_color += myLights[i].color() * pow(  dot( sv.normal , half ) , sv.phongexponent );
	}
    }
    
    highlight_color *= sv.highlight;
    rgb diffuse_color =  sv.matte * ( ambient() + allLight );

    vector3d mirroredVec =  r.direction() - 2 * dot( sv.normal , r.direction() ) * sv.normal;
    
    rgb mirror_color = sv.mirror * color( ray( r.eval(t), mirroredVec ) , epsilon , tmax ) ;
    
    return diffuse_color + mirror_color + highlight_color;
  }
  return background();
*/
  surfacevals rec;
  surfacevals srec;
  double t,dumbt;
  if (mySurfaces->hit(r, tmin, tmax, t , rec)) {
    rgb colort = rec.matte*ambient();
    double cosine;
    for (int i = 0; i < myLights.length(); i++) {
      ray sray(r.eval(t), myLights[i].direction());
      if (!mySurfaces->hit(sray, 0.01, MYMAXFLOAT, dumbt, srec)) {
	if ( (cosine = dot( myLights[i].direction() , rec.normal )) > 0.0) {
	  colort += rec.matte*myLights[i].color()*cosine;
          vector3d h = unitVector(myLights[i].direction()-r.direction());
          colort += rec.highlight * pow( dot(rec.normal,h), rec.phongexponent) * myLights[i].color();
        }
      }
    }
    if (rec.mirror != rgb(0,0,0)) {
      vector3d reflected_direction = r.direction() - 2*dot(r.direction(),rec.normal)*rec.normal; 
      colort += rec.mirror*color( ray(r.eval(t), reflected_direction), 0.000001,MYMAXFLOAT);
    }
    return colort;
  }
  else
    return background();
}


















