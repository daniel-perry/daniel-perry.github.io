#include "axisbox.h"

axisbox::axisbox()
{
  setp0( vector3d(0,0,0) );
  setp1( vector3d(1,1,1) );
  setmatte( rgb(1,1,1) );
  setmirror( rgb(0,0,0) );
  sethighlight( 0.0 );
  setphongexponent( 1.0 );
}

axisbox::axisbox( const vector3d & np0, const vector3d & np1, const rgb & kd, const rgb & ks, double kh, double e )
{
  setp0( np0 );
  setp1( np1 );
  setmatte( kd );
  setmirror( ks );
  sethighlight( kh );
  setphongexponent( e );
}

bool axisbox::hit (const ray & r, double tmin, double tmax, double & t, surfacevals & sv ) const
{
  if ( ray_box_intersect( r , p0() , p1() , tmin , tmax , sv.normal , t ) )
  {
    sv.matte = matte();
    sv.mirror = mirror();
    sv.highlight = highlight();
    sv.phongexponent = phongexponent();
    sv.normal /= sv.normal.length();
    return true;
  }
  
  return false;
}

vector3d axisbox::centroid() const
{
  return ( p0() + p1() ) / 2 ;
}

dynarray<vector3d> axisbox::elements() const
{
  dynarray<vector3d> myvarray;
  myvarray.append(p0());
  myvarray.append(p1());
  return myvarray;
}
