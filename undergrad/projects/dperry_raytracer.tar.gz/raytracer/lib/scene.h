#ifndef _SCENE_H
#define _SCENE_H

#include "dynarray.h"
#include "surface.h"
#include "light.h"
#include "boundingbox.h"
#include "hbv_node.h"

class scene
{
 public:
  scene () {}
  void read(istream & is);
  rgb color( const ray & r, double tmin, double tmax );

  void addlight( const light & l ) { myLights.append(l); }
  //void addsurface( surface * s ) { mySurfaces.append(s); }
  void setbackground( const rgb & bg ) { myBackground=rgb(bg); }
  void setambient( const rgb & amb ) { myAmbient=rgb(amb); }

  //bool hit( const ray & r, double tmin, double tmax, double & t, surfacevals & sv);

  rgb background() const { return myBackground; }
  rgb ambient() const { return myAmbient; }

  //private:
  surface *mySurfaces;
  dynarray<light> myLights;
  rgb myBackground;
  rgb myAmbient;
};

surface * build_tree ( const dynarray<surface*> objectList , int axis );

int compareX ( const void * v1 , const void * v2 );
int compareY ( const void * v1 , const void * v2 );
int compareZ ( const void * v1 , const void * v2 );
    
#endif







