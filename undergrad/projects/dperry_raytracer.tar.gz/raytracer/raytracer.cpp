// This code written by Daniel Perry (dperry@cs.utah.edu)

#include <iostream.h>
#include "lib/image.h"
#include "lib/sphere.h"
#include "lib/scene.h"

#include <float.h>

#define MYMAXFLOAT FLT_MAX
// Linux: FLT_MAX
// Sun: MAXFLOAT

int main()
{  
  int nx,ny;
  nx = ny = 500;

  scene s;
  s.read( cin );
  
  image im( nx, ny );

  for (int x = 0; x< nx ; x++)
  {
    for (int y = 0; y<ny ; y++)
    {
      im.set( x , y , s.color( ray( vector3d(0,0,0) , vector3d((x-nx/2.)/nx, (y-ny/2.)/ny, -1 ) ), 0, MYMAXFLOAT ) );
    }
  }
 
  im.writeppm( cout );
  
  return 0;
}
//g++ vector3d.cpp ray.cpp rgb.cpp sphere.cpp triangle.cpp axisbox.cpp scene.cpp image.cpp raytracer.cpp -o raytracer
